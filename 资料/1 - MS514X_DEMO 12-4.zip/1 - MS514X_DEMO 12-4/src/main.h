#ifndef __MAIN_H
#define __MAIN_H

#include "stm32f10x.h"
#include "stdbool.h"
#include "string.h"

#define MS5194

#define Vref 2.04884
#define uart1_rxbuf_num_max 40

typedef enum { 
	COMMAND_NORMAL = 0x00,
	COMMAND_Write_reg = 0x01,
	COMMAND_Write_data = 0x02,
	COMMAND_Read_reg = 0x11,
	COMMAND_CConvert = 0x21,
}	COMMAND_TYPE;

typedef enum { 
	Mode_inside_temp = 0x01,
	Mode_NTC = 0x02,
	Mode_K_T = 0x03,
	Mode_RTD = 0x04,
	Mode_Weight = 0x05,
	
	
	Mode_K_T2 = 0x06,
	Mode_TC_DR20_PGA32 = 0x07,
	Mode_TC_DR40_PGA16 = 0x08,
	Mode_TC_DR80_PGA32 = 0x09,
	Mode_TC_DR160_PGA32 = 0x0A,
	Mode_TC_DR1K_PGA16 = 0x0B,
}	Work_Mode_TYPE;

#define TIMES_inside_temp 4
#define TIMES_NTC 8
#define TIMES_K_T 4
#define TIMES_RTD 2
#define TIMES_WEIGHT 8

typedef enum	{
	_0_BYTE = 0,
	_1_BYTE = 1,
	_2_BYTE = 2,
#if   (defined MS5193) || (defined MS5199) || (defined MS5194) || (defined MS5185)
	_3_BYTE = 3
#elif (defined MS5192) || (defined MS5198) || (defined MS5195)
	_3_BYTE = _2_BYTE
#endif
}	DUT_DATA_LEN;

#endif
