#ifndef _FUNCTION_H_
#define _FUNCTION_H_

#include "main.h"
#include "DUT_reg.h"

bool _processing_USART1data(int *data);
void displayREGname(Register_TYPE REGname);

bool _convert_Times(int *times);
void _Single_Convert(int *DATA);
void _Continuity_Converts_Command(void);
void _Continuity_Converts_Read(int *DATA);
void _Stop_Convert_Command(void);

void print(USART_TypeDef* USARTx,char *string);
void PrintHEX(USART_TypeDef *USARTx,int HEXDATA);

#endif

