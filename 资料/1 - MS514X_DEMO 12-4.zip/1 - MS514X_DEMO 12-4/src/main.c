	/**
  ******************************************************************************
  * @file    main.c
  * @author  WYZ
  * @version V1.0
  * @date    2023-05-22
  * @brief   �����������·ͨ��ʹ�õ���SPI2
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, RELMON SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  ******************************************************************************
  **/

/* Includes ------------------------------------------------------------------*/
#include <stm32f10x.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
//#include <system.h>

#include "main.h"
#include "Delay.h"
#include "initial.h"
#include "CTRL.h"
#include "DUT_reg.h"
#include "functional.h"

int uart1_rxbuf_num;
char uart1_rxbuf[uart1_rxbuf_num_max] = {0};
bool UART1_Receive_flag = false;
bool DRDY_flag = false;

DUT_DATA_LEN DATA_BYTE;
int Value;

uint16_t RegList[15];
uint16_t SetList[15];

Work_Mode_TYPE work_mode;
double AVG_value;

COMMAND_TYPE U_COMMAND =COMMAND_NORMAL;
Register_TYPE program_register;
int Continuity_Convert_Times;
bool Continuity_Convert_flag=false;
int CCcalnum;

#define _PRINTF_
int fputc(int ch,FILE *f)
{
	USART_SendData(USART1,(unsigned char)ch);
	while(!(USART1->SR & USART_FLAG_TXE));
	return (ch);
}

int main(void)
{
	Initialization();
	
	printf("\t******** MS5148 DEMO  ********\r\n");	

	printf("\n\t WELCOM TO HZ RUIMENG TECHNOLOGY!!\r");	
	printf("\n\t WEBSITE: www.relmon.com \r\n");
	
	printf("\n\t #Copy-R 2024-11# \r");
	printf("\n\t (^AQ^) \r\n\n\n");
	
	Reset_Device();
	SPI_ReadReg(MUX0,15,RegList);
	printf("\n\t RESET READY!\r",(uint8_t)(RegList[10]>>4));
	printf("\t          Please choose No. 1 or 2 to 9 \r");
  printf("\n\t          Enter! \r\n");
	
	printf("\n");
	printf("\t1. TEMPERATURE SENSOR!!       \r\n");
	printf("\t2. RTD CHANNEL!!                 \r\n");
	printf("\t>> TC CHANNEL!! (A0-A1)       \r\n");
	printf("\t3. TC CHANNEL= DR5  PGA=1 Burnout on   \r\n");
	printf("\t4. TC CHANNEL= DR5  PGA=1 Burnout off  \r\n");
	printf("\t5. TC CHANNEL= DR20   PGA=32 Burnout on  \r\n");
	printf("\t6. TC CHANNEL= DR40   PGA=16 Burnout on  \r\n");		
	printf("\t7. TC CHANNEL= DR80   PGA=32 Burnout on  \r\n");	
	printf("\t8. TC CHANNEL= DR160  PGA=32 Burnout on  \r\n");		
	printf("\t9. TC CHANNEL= DR1k   PGA=16 Burnout on  \r\n");	
		
	/*		|| work_mode == Mode_TC_DR20_PGA16 
			  || work_mode == Mode_TC_DR20_PGA32 
			  || work_mode == Mode_TC_DR40_PGA16 
			  || work_mode == Mode_TC_DR80_PGA32
		  	|| work_mode == Mode_TC_DR160_PGA32
			  || work_mode == Mode_TC_DR1K_PGA16 */
				
	
	int value[16]={0};
	double inside_tempture_data, RTD_Value1, RTD_Value2, TC_Voltage;
	bool RTD_Iout1,RTD_Iout2;
	while(1)
	{
		if (Continuity_Convert_Times==-1)
		{    
			
			/*---------------------WORK MODE 1---------------------------------*/
			
			if ( work_mode == Mode_inside_temp )																									// Temperture sensor
			{
				inside_tempture_data = ( Vref*(AVG_value)/16777216*2 - 0.1036)/0.0003749;		//Temperature Drift 0.379mV
				printf("Temperature: %7.1f  Degree!\n",inside_tempture_data);												//Print [7-long, 0.1 pricision,Float data, Degree,return] [Upper data]
				Continuity_Convert_Times = TIMES_inside_temp;																				//Was #define TIMES_inside_temp 4
				EXTI->PR   = _EXTI_DUT_DRDY;																												//Clear intterupt EXIT flat
				EXTI->IMR |= _EXTI_DUT_DRDY;																												//Enable external Intterupt EXIT
			}	
			
				/*---------------------WORK MODE 2---------------------------------*/
			
			if ( work_mode == Mode_RTD )																													// 3-Wire RTD, Mode_RTD = 0x04
			{
				if( RTD_Iout1 )
				{
					RTD_Value1 = (AVG_value/8388607)*2200*2;																					// RTD Value = Code Data/2^23 = Value/3kR?, in EVB it is 2KR for VREF	
//				RTD_Value1 = ((Vref*(AVG_value/16777216)*2)/16)/0.0001;
  				printf("%8.4f\n",RTD_Value1);																										  // Print RTD Value R
					Continuity_Convert_Times = TIMES_RTD;																							// #define TIMES_RTD 6
					EXTI->PR   = _EXTI_DUT_DRDY;
					EXTI->IMR |= _EXTI_DUT_DRDY ;					
				}
			}
			
			/*---------------------WORK MODE 3 4 5 6 7 8 9---------------------------------*/
			
			if ( work_mode == Mode_K_T 
				|| work_mode == Mode_K_T2
		  	|| work_mode == Mode_TC_DR20_PGA32
				|| work_mode == Mode_TC_DR40_PGA16
				|| work_mode == Mode_TC_DR80_PGA32
				|| work_mode == Mode_TC_DR160_PGA32
				|| work_mode == Mode_TC_DR1K_PGA16)																													// TC Channel, AVG_value output
			{
					double TC_Voltage = (Vref * (AVG_value)/8388607)/32;
					printf("%2.8f \n",TC_Voltage); 
			  	Continuity_Convert_Times = TIMES_K_T;

					EXTI->PR   = _EXTI_DUT_DRDY;
					EXTI->IMR |= _EXTI_DUT_DRDY ;
			}
			
/*						if ( work_mode == Mode_TC_DR10_PGA64 )									
			{
					double TC_Voltage = (Vref * (AVG_value)/8388607)/64;
					printf("%8.7f \n",TC_Voltage); 
			  	Continuity_Convert_Times = TIMES_K_T;

					EXTI->PR   = _EXTI_DUT_DRDY;
					EXTI->IMR |= _EXTI_DUT_DRDY ;
			}

						if ( work_mode == Mode_TC_DR20_PGA32 )											
			{
					double TC_Voltage = (Vref * (AVG_value)/8388607)/32;
					printf("%8.7f \n",TC_Voltage); 
			  	Continuity_Convert_Times = TIMES_K_T;

					EXTI->PR   = _EXTI_DUT_DRDY;
					EXTI->IMR |= _EXTI_DUT_DRDY ;
			}
			
						if ( work_mode == Mode_TC_DR40_PGA16 )																													// TC Channel, AVG_value output
			{
					double TC_Voltage = (Vref * (AVG_value)/8388607)/16;
					printf("%8.7f \n",TC_Voltage); 
			  	Continuity_Convert_Times = TIMES_K_T;

					EXTI->PR   = _EXTI_DUT_DRDY;
					EXTI->IMR |= _EXTI_DUT_DRDY ;
			}
			
						if ( work_mode == Mode_TC_DR80_PGA32 )																													// TC Channel, AVG_value output
			{
					double TC_Voltage = (Vref * (AVG_value)/8388607)/32;
					printf("%8.7f \n",TC_Voltage); 
			  	Continuity_Convert_Times = TIMES_K_T;

					EXTI->PR   = _EXTI_DUT_DRDY;
					EXTI->IMR |= _EXTI_DUT_DRDY ;
			}
			
						if ( work_mode == Mode_TC_DR160_PGA32 )																													// TC Channel, AVG_value output
			{
					double TC_Voltage = (Vref * (AVG_value)/8388607)/32;
					printf("%8.7f \n",TC_Voltage); 
			  	Continuity_Convert_Times = TIMES_K_T;

					EXTI->PR   = _EXTI_DUT_DRDY;
					EXTI->IMR |= _EXTI_DUT_DRDY ;
			}
			
						if ( work_mode == Mode_TC_DR1K_PGA16 )																													// TC Channel, AVG_value output
			{
					double TC_Voltage = (Vref * (AVG_value)/8388607)/16;
					printf("%8.7f \n",TC_Voltage); 
			  	Continuity_Convert_Times = TIMES_K_T;

					EXTI->PR   = _EXTI_DUT_DRDY;
					EXTI->IMR |= _EXTI_DUT_DRDY ;
			}
*/			
			
			
			
			
			

			
			
		}

/*------------------------------------------------FLAG READY?----------------------------------------------------------*/		

if(UART1_Receive_flag)
  {
	 UART1_Receive_flag = false;
	if( (uart1_rxbuf[0]=='1') || (uart1_rxbuf[0]=='2') || (uart1_rxbuf[0]=='3') || (uart1_rxbuf[0]=='4') || (uart1_rxbuf[0]=='5') || (uart1_rxbuf[0]=='0') )
		 {
			printf("--> UART1_Receive -->Ready !!! \r\r\n");        
			waiting_DRDY();
			_Stop_Convert_Command();
		 }
			
/*-----------------------------------------------CONTROL1--------------------------------------------------------------*/	 
		 
			if(!strncmp(uart1_rxbuf,"1",1))		
//				delay_ms(1);
			{
				printf("-->MS514X Internal Temperature Sensor, Unit Degree!!!\r\r\n");					// Print my shit!!!
				SetList[SYS0] = 0;																															// 0x03h = 0000000 -> DR=5 PGA=1
				SPI_WriteReg(SYS0,1,SetList);																										// W-REG: uint8_t FirstAddr, uint8_t Length, uint16_t *DATA
				SetList[MUX1] = (VREFCON0)|(REFSEL1)|(MUXCAL0|MUXCAL1);													// 02h = 0x20|0x10|(0x01|0x02) = 0x33  0 0110 011 In-CLK / SAVE / Temper
				SPI_WriteReg(MUX1,1,SetList);																										// W-REG
				SPI_ReadReg(MUX0,15,RegList);																										// R-REG: uint8_t FirstAddr,uint8_t Length,uint16_t *DATA       0X00, Burnout Reg
				_Continuity_Converts_Command();																									// CS_L, SPI Write 0X14
				Continuity_Convert_Times = 1 + TIMES_inside_temp;																// define TIMES_inside_temp 4
				CCcalnum   = TIMES_inside_temp;																								  // variable assignment***
				EXTI->PR   = _EXTI_DUT_DRDY;																										// Clear intterupt
				EXTI->IMR |= _EXTI_DUT_DRDY;																										// Enable External interupt
				work_mode = Mode_inside_temp;																										// Mode_inside_temp = 0x01
			}		

/*----------------------------------------------CONTROL2---------------------------------------------------------*/			
			
			if(!strncmp(uart1_rxbuf,"2",1))																										// ----> External 3-Wire RTD!
			{
				printf("-->3-Wire RTD Channel, Unit R!!! \r\n");                                                  

				//--- Code Ouput: Principle
				//--- Set Channel -> Set PGA -> Set DR -> Set VREF -> 
				//--- IDAC on -> Read , Switch IDAC -> Read
				//--- 
				//--- Output code 1 = 2^23 * [IDAC1 * (R-RTD + R-LEAD1) - (IDAC2 * RLEAD2)] / [(IDAC1 + IDAC2) * RREF]			--> A
				//--- Output code 2 = 2^23 * [IDAC2 * (R-RTD + R-LEAD1) - (IDAC1 * RLEAD2)] / [(IDAC1 + IDAC2) * RREF]		  --> B
				//--- Current Switch mode: (A+B)/2 
				// IEXC0 IEXC1 AIN2 AIN3
				
				SetList[MUX0] = (MUX_SP1)|(MUX_SN1|MUX_SN0); 																		// 0x10|0x02|0x01 = 0x13 00010011 -> AIN+2 AIN-3,Burnout off
				SPI_WriteReg(MUX0,1,SetList);

				SetList[SYS0] = (DR1);     																											// PGA DR	
				SPI_WriteReg(SYS0,1,SetList);
			
				SetList[MUX1] = (VREFCON0)|(REFSEL0)|(MUXCAL1); 																// MUX1=0X02	Set VREF						
				SPI_WriteReg(MUX1,1,SetList);
					
				DUT_CS_L; 
				SPI_Write(Sysgcal);																															// Sysgcal=0x61		Gain Calibration code
				DUT_CS_H; 
				waiting_DRDY();
				
				SetList[MUX1] = (VREFCON0)|(REFSEL0)&(~(MUXCAL0|MUXCAL1|MUXCAL2)); 							// 0x02, 0x20|0x08|&(~(0x01|0x02|0x04)) = 0x48  Config MUX
				SPI_WriteReg(MUX1,1,SetList);

				SPI_ReadReg(MUX0,15,RegList);																										// Readback
				
				SetList[IDAC0] = IMAG1;																													// IMAG1=0X02, DRDY&IDAC
				SPI_WriteReg(IDAC0,1,SetList);

				SetList[IDAC1] = 0x89; 																													// IDAC Channel, EXC1, EXC2
				SPI_WriteReg(IDAC1,1,SetList);

				SPI_ReadReg(MUX0,15,RegList);
				RTD_Iout1 = true;
				RTD_Iout2 = false;
				_Continuity_Converts_Command();																									// Send 0x14
				Continuity_Convert_Times = 1 + TIMES_RTD;
				CCcalnum   = 1;																																  // variable assignment***

				EXTI->PR   = _EXTI_DUT_DRDY;																										// EXTI->PR = EXTI_Line11;
				EXTI->IMR |= _EXTI_DUT_DRDY;																										// EXTI->IMR = EXTI->IMR | EXTI_Line11;

				work_mode = Mode_RTD;
			}

/*-----------------------------------------------CONTROL3 TC test Burnout On----------------------------------------------------------------*/
			//  	 Basic logic:
			//	1. REF Select. 
			//	2. AIN Channel Select 
			//	3. PGA on 
			//	4. Select DR 
			//	5. Burnout On(Selectable) 
			//	6. Cold Junction read.  
			
			if(!strncmp(uart1_rxbuf,"3",1))																										// -----> TC CHANNEL!
			{
				printf("--->TC Channel, DR=5 PGA=1, Burnout On, Unit Volt!!! \r\n");
				
				SetList[MUX1] = (VREFCON0)|(REFSEL1)|(MUXCAL1);																	// =0x32 Mode Select Gain 
				SPI_WriteReg(MUX1,1,SetList);

				SetList[MUX0] = 0x01;																														// MUX0 for  Channel select
				SPI_WriteReg(MUX0,1,SetList);

				SetList[SYS0] = (DRz);     																							   			// SYS0 for DR PGA; PGA=1; DR0=5 sps
				SPI_WriteReg(SYS0,1,SetList);

				SetList[VBIAS] = (0x02);																												// AIN1 VBIAS OPEN
				SPI_WriteReg(VBIAS,1,SetList);
				
				DUT_CS_L; 
				SPI_Write(Sysgcal);																															// Gain Clalibration			
//				SPI_Write(Selfocal);
				DUT_CS_H; 
				waiting_DRDY();

 			  SetList[MUX0] = 0xC1;																														// MUX0 for Burnout & Channel select
			  SPI_WriteReg(MUX0,1,SetList);
				
				SetList[MUX1] = (VREFCON0)|(REFSEL1)&(~(MUXCAL0|MUXCAL1|MUXCAL2));					//  0X30 / Normal Mode / Open IN-VREF
				SPI_WriteReg(MUX1,1,SetList);



				_Continuity_Converts_Command();
				Continuity_Convert_Times = 1 + TIMES_RTD;
				CCcalnum   = 1;																								                 // variable assignment***

				EXTI->PR   = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;

				work_mode = Mode_K_T;
			 }

			 /*----------------------------------------CONTROL4----------------------------------------------------------------*/
			if(!strncmp(uart1_rxbuf,"4",1))																										// -----> TC CHANNEL!
			{
				printf("--->TC Channel, DR=5 PGA=1, Burnout off, Unit Volt!!! \r\n");
			
  			SetList[MUX0] = 0x01;																														// MUX0 for Burnout & Channel select
				SPI_WriteReg(MUX0,1,SetList);
				
				SetList[SYS0] = (DRz);     																							   			// SYS0 for DR PGA; PGA=1; DR0=5 sps
				SPI_WriteReg(SYS0,1,SetList);
				
				SetList[MUX1] = (VREFCON0)|(REFSEL1)|(MUXCAL1);																	// =0x32 Mode Select Gain 
				SPI_WriteReg(MUX1,1,SetList);
								
				DUT_CS_L; 
				SPI_Write(Sysgcal);																															// Gain Clalibration				
				DUT_CS_H; 
				waiting_DRDY();
				
				SetList[MUX1] = (VREFCON0)|(REFSEL1)&(~(MUXCAL0|MUXCAL1|MUXCAL2));					   //  0X30 / Normal Mode / Open IN-VREF
				SPI_WriteReg(MUX1,1,SetList);

				SetList[VBIAS] = (0x02);																												// AIN0 VBIAS OPEN
				SPI_WriteReg(VBIAS,1,SetList);

				_Continuity_Converts_Command();
				Continuity_Convert_Times = 1 + TIMES_RTD;
				CCcalnum   = 1;																								                 // variable assignment***

				EXTI->PR   = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;

				work_mode = Mode_K_T2;
			 }

			 /*----------------------------------------CONTROL5----------------------------------------------------------------*/
			
			if(!strncmp(uart1_rxbuf,"5",1))																										// -----> TC CHANNEL!
			{
				printf("--->TC Channel Mode_TC_DR20_PGA32, Unit Volt!!! \r\n");

				SetList[MUX0] = 0x01;																														// Burnout on, AIN0 AIN1
				SPI_WriteReg(MUX0,1,SetList);
				
				SetList[SYS0] = (DR20P32);     																							   			// PGA & DR
				SPI_WriteReg(SYS0,1,SetList);
				
				SetList[MUX1] = (VREFCON0)|(REFSEL1)|(MUXCAL1);																	// Config 00110010 Gain-Calib Prepare(CLK,VREF-ON,MODE)
				SPI_WriteReg(MUX1,1,SetList);
								
				DUT_CS_L; 
				SPI_Write(Sysgcal);																																			
				DUT_CS_H; 
				waiting_DRDY();

				SetList[MUX1] = (VREFCON0)|(REFSEL1)&(~(MUXCAL0|MUXCAL1|MUXCAL2));							// Config 00110000 Normal Mode, Open IN-VREF
				SPI_WriteReg(MUX1,1,SetList);

				SetList[VBIAS] = (0x02);																												// AIN1 VBIAS OPEN
				SPI_WriteReg(VBIAS,1,SetList);

				_Continuity_Converts_Command();
				Continuity_Convert_Times = 1 + TIMES_RTD;
				CCcalnum   = TIMES_inside_temp;																								  // variable assignment***

				EXTI->PR   = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;

				work_mode = Mode_TC_DR20_PGA32;
			 }

			 /*----------------------------------------CONTROL6----------------------------------------------------------------*/
			
			if(!strncmp(uart1_rxbuf,"6",1))																										// -----> TC CHANNEL!
			{
				printf("--->TC Channel Mode_TC_DR40_PGA16, Unit Volt!!! \r\n");

				SetList[MUX0] = 0x01;																														// Burnout on, AIN0 AIN1
				SPI_WriteReg(MUX0,1,SetList);
				
				SetList[SYS0] = (DR40P16);     																							   			// PGA & DR
				SPI_WriteReg(SYS0,1,SetList);
				
				SetList[MUX1] = (VREFCON0)|(REFSEL1)|(MUXCAL1);																	// Config 00110010 Gain-Calib Prepare(CLK,VREF-ON,MODE)
				SPI_WriteReg(MUX1,1,SetList);
								
				DUT_CS_L; 
				SPI_Write(Sysgcal);																																			
				DUT_CS_H; 
				waiting_DRDY();

				SetList[MUX1] = (VREFCON0)|(REFSEL1)&(~(MUXCAL0|MUXCAL1|MUXCAL2));							// Config 00110000 Normal Mode, Open IN-VREF
				SPI_WriteReg(MUX1,1,SetList);

				SetList[VBIAS] = (0x02);																												// AIN0 VBIAS OPEN
				SPI_WriteReg(VBIAS,1,SetList);

				_Continuity_Converts_Command();
				Continuity_Convert_Times = 1 + TIMES_RTD;
				CCcalnum   = TIMES_inside_temp;																								  // variable assignment***

				EXTI->PR   = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;

				work_mode = Mode_TC_DR40_PGA16;
			 }

			 /*----------------------------------------CONTROL7----------------------------------------------------------------*/
			
			if(!strncmp(uart1_rxbuf,"7",1))																										// -----> TC CHANNEL!
			{
				printf("--->TC Channel Mode_TC_DR80_PGA32, Unit Volt!!! \r\n");

				SetList[MUX0] = 0xC1;																														// Burnout on, AIN0 AIN1
				SPI_WriteReg(MUX0,1,SetList);
				
				SetList[SYS0] = (DR80P32);     																							   			// PGA & DR
				SPI_WriteReg(SYS0,1,SetList);
				
				SetList[MUX1] = (VREFCON0)|(REFSEL1)|(MUXCAL1);																	// Config 00110010 Gain-Calib Prepare(CLK,VREF-ON,MODE)
				SPI_WriteReg(MUX1,1,SetList);
								
				DUT_CS_L; 
				SPI_Write(Sysgcal);																																			
				DUT_CS_H; 
				waiting_DRDY();

				SetList[MUX1] = (VREFCON0)|(REFSEL1)&(~(MUXCAL0|MUXCAL1|MUXCAL2));							// Config 00110000 Normal Mode, Open IN-VREF
				SPI_WriteReg(MUX1,1,SetList);

				SetList[VBIAS] = (0x02);																												// AIN0 VBIAS OPEN
				SPI_WriteReg(VBIAS,1,SetList);

				_Continuity_Converts_Command();
				Continuity_Convert_Times = 1 + TIMES_RTD;
				CCcalnum   = TIMES_inside_temp;																								  // variable assignment***

				EXTI->PR   = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;

				work_mode = Mode_TC_DR80_PGA32;
			 }

			 /*----------------------------------------CONTROL8----------------------------------------------------------------*/
			
			if(!strncmp(uart1_rxbuf,"8",1))																										// -----> TC CHANNEL!
			{
				printf("--->TC Channel Mode_TC_DR160_PGA32, Unit Volt!!! \r\n");

				SetList[MUX0] = 0xC1;																														// Burnout on, AIN0 AIN1
				SPI_WriteReg(MUX0,1,SetList);
				
				SetList[SYS0] = (DR160P32);     																							   			// PGA & DR
				SPI_WriteReg(SYS0,1,SetList);
				
				SetList[MUX1] = (VREFCON0)|(REFSEL1)|(MUXCAL1);																	// Config 00110010 Gain-Calib Prepare(CLK,VREF-ON,MODE)
				SPI_WriteReg(MUX1,1,SetList);
								
				DUT_CS_L; 
				SPI_Write(Sysgcal);																																			
				DUT_CS_H; 
				waiting_DRDY();

				SetList[MUX1] = (VREFCON0)|(REFSEL1)&(~(MUXCAL0|MUXCAL1|MUXCAL2));							// Config 00110000 Normal Mode, Open IN-VREF
				SPI_WriteReg(MUX1,1,SetList);

				SetList[VBIAS] = (0x02);																												// AIN0 VBIAS OPEN
				SPI_WriteReg(VBIAS,1,SetList);

				SPI_ReadReg(MUX0,15,RegList);																										// Readback

				_Continuity_Converts_Command();
				Continuity_Convert_Times = 1 + TIMES_RTD;
				CCcalnum   = TIMES_inside_temp;																								  // variable assignment***

				EXTI->PR   = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;

				work_mode = Mode_TC_DR160_PGA32;
			 }

			 /*----------------------------------------CONTROL9----------------------------------------------------------------*/
			
			if(!strncmp(uart1_rxbuf,"9",1))																										// -----> TC CHANNEL!
			{
				printf("--->TC Channel Mode_TC_DR1K_PGA16, Unit Volt!!! \r\n");

				SetList[MUX0] = 0xC1;																														// Burnout on, AIN0 AIN1
				SPI_WriteReg(MUX0,1,SetList);
				
				SetList[SYS0] = (DR1KP16);     																							   			// PGA & DR
				SPI_WriteReg(SYS0,1,SetList);
				
				SetList[MUX1] = (VREFCON0)|(REFSEL1)|(MUXCAL1);																	// Config 00110010 Gain-Calib Prepare(CLK,VREF-ON,MODE)
				SPI_WriteReg(MUX1,1,SetList);
								
				DUT_CS_L; 
				SPI_Write(Sysgcal);																																			
				DUT_CS_H; 
				waiting_DRDY();

				SetList[MUX1] = (VREFCON0)|(REFSEL1)&(~(MUXCAL0|MUXCAL1|MUXCAL2));							// Config 00110000 Normal Mode, Open IN-VREF
				SPI_WriteReg(MUX1,1,SetList);

				SetList[VBIAS] = (0x02);																												// AIN0 VBIAS OPEN
				SPI_WriteReg(VBIAS,1,SetList);

				_Continuity_Converts_Command();
				Continuity_Convert_Times = 1 + TIMES_RTD;
				CCcalnum   = TIMES_inside_temp;																								  // variable assignment***

				EXTI->PR   = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;

				work_mode = Mode_TC_DR1K_PGA16;
			 }
			 
  }
		if(DRDY_flag==true)
		{
			DRDY_flag = false;
			if(Continuity_Convert_Times--)                                                // - till = 0, to else
			{
				_Continuity_Converts_Read(&value[Continuity_Convert_Times+1]);              
				EXTI->IMR |= _EXTI_DUT_DRDY;																								// Enable EXTI line 14						GD32F103 BUG��
				EXTI->PR   = _EXTI_DUT_DRDY;																								// Clear EXTI line 14 flag bit		The flag must be cleared immediately after the interrupt is enable
			}
			else
			{
				_Continuity_Converts_Read(&value[Continuity_Convert_Times+1]);							// Read over
				DUT_CS_H;
				int SUM_value=0;
				for( int i=0;i<CCcalnum;i++)
				{
					SUM_value += value[i];																									  // Sum_value = Sum_value + Value[i]
				}
				AVG_value = (double)SUM_value/CCcalnum;                                     // 
//  		EXTI->IMR = _EXTI_DUT_DRDY;																							  	// Set _EXTI_DUT_DRDY flag bit
				EXTI->PR = _EXTI_DUT_DRDY;																								  // Clear _EXTI_DUT_DRDY flag bit
			}
		}
	
	}
}
void USART1_IRQHandler(void)
{
		uart1_rxbuf[uart1_rxbuf_num]=(uint8_t)USART_ReceiveData(USART1);
		uart1_rxbuf_num++;
		USART_ClearFlag(USART1,USART_FLAG_RXNE);
		
		if(uart1_rxbuf_num==uart1_rxbuf_num_max)  uart1_rxbuf_num=0;
//  if( (uart1_rxbuf[uart1_rxbuf_num-1]==0x0D) )
		{
			UART1_Receive_flag = true;
			uart1_rxbuf_num =0;
		}
}

void EXTI15_10_IRQHandler(void)
{
		if(EXTI_GetITStatus(_EXTI_DUT_DRDY) != RESET)
		{
				EXTI->IMR &= ~(_EXTI_DUT_DRDY);						// disable _EXTI_DUT_DRDY
				EXTI->PR 	 =   _EXTI_DUT_DRDY;						// Clear  _EXTI_DUT_DRDY flag
				DRDY_flag  = true;
		}
}
