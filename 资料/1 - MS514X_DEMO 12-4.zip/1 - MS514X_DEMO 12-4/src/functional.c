	/**
  ******************************************************************************
  * @file    functional.c
  * @author  WYZ
  * @version V1.0
  * @date    2023-05-20
  * @brief   ���ຯ��
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "functional.h"
#include "CTRL.h"

extern char uart1_rxbuf[uart1_rxbuf_num_max];
extern DUT_DATA_LEN DATA_BYTE;

bool _processing_USART1data(int *data)
{
	if( ( uart1_rxbuf[0] != '0' ) || ( uart1_rxbuf[1] != 'X' ) )
	{
		print (USART1,"Parameter ERROR\n");
		return false;
	}
	*data=0;
	for(int i=2;i<8;i++)
	{	*data <<= 4;
		*data |= (uart1_rxbuf[i]>0x39) ? (uart1_rxbuf[i]-55) : (uart1_rxbuf[i]-0x30) ;
	}
	return true;
}
void displayREGname(Register_TYPE REGname)
{
	DATA_BYTE = _1_BYTE;
	PrintHEX(USART1,REGname);	// ������ʾ�Ĵ�����HEXֵ
//	switch (REGname)
//	{
//		case STATEreg:			print (USART1,"       STATE : ");	break;
//		case MODEreg:				print (USART1,"        MODE : ");	break;
//		case CONFIGreg:			print (USART1,"      CONFIG : ");	break;
//		case DATAreg:				print (USART1,"        DATA : ");	break;
//		case IDreg:					print (USART1,"          ID : ");	break;
//		case IOreg:					print (USART1,"          IO : ");	break;
//		case OFFSETreg:			print (USART1,"      OFFSET : ");	break;
//		case FULLSCALEreg:	print (USART1,"   FULLSCALE : ");	break;
//		default:break;
//	}
}

bool _convert_Times(int *times)
{
	if( ( uart1_rxbuf[8] != ' ' ) || ( uart1_rxbuf[13] != 's' ) )
	{
		print (USART1,"Parameter ERROR\n");
		return false;
	}
	*times= (uart1_rxbuf[9]-0x30)*1000 + \
					(uart1_rxbuf[10]-0x30)*100 + \
					(uart1_rxbuf[11]-0x30)*10 + \
					(uart1_rxbuf[12]-0x30);
	return true;
}

void _Single_Convert(int *DATA)
{
//	SPI_Read(MODEreg,DATA);
//	*DATA &= 0X1FFF;
//	*DATA |= MD_SINGLE;
//	SPI_Write(MODEreg,*DATA);
//	waiting_DRDY();
//	SPI_Read(DATAreg,&*DATA);
}

void _Continuity_Converts_Command(void)
{
	int DATA;
	 DUT_CS_L; // Pull down CS,check DRDY
	 SPI_Write(Rdatac);																						
}
void _Continuity_Converts_Read(int *DATA)
{
	 DUT_CS_L;
	DATA_BYTE = _3_BYTE;
	*DATA =0;
	for(int i=0;i<DATA_BYTE;i++)
	{
		*DATA <<= 8;
		SPI2->DR = 0xff;	// NOP Command
		while( (SPI2->SR & SPI_I2S_FLAG_TXE)  == RESET ){}
		while( (SPI2->SR & SPI_I2S_FLAG_RXNE) == RESET){}
		while( (SPI2->SR & SPI_I2S_FLAG_BSY) != RESET ){}
		*DATA |= (uint8_t)SPI2->DR;
	}
	
	 DUT_CS_H;
}

void _Stop_Convert_Command(void)
{
	int DATA;
//	SPI_Write(COMMUNICATIONreg,DATAreg|READREG);
//	SPI_Read(MODEreg,&DATA);
//	DATA &= 0X1FFF;
//	DATA |= MD_PRDN;
//	SPI_Write(MODEreg,DATA);		// like after Single_Convert, set IC in PowerDown mode
}

void print(USART_TypeDef* USARTx,char *string)
{
  char len=0;
  len=strlen(string);
	for(char i=0;i<len;i++)
	{
		USART_SendData(USARTx, *string);
		while (USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);	
		string++;
	}
}

void PrintHEX(USART_TypeDef *USARTx,int HEXDATA)
{
	for(char i=DATA_BYTE*2;i>0;i--)
	{
		char Letter= (HEXDATA>>(i*4-4))&0xf;
		Letter= (Letter>9) ? (Letter+55) : (Letter+0x30) ;
		USART_SendData(USARTx, Letter);
		while (USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);	
	}
	USART_SendData(USARTx, '\n');
	while (USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);	
}

