 	/**
  ******************************************************************************
  * @file    CTRL.c
  * @author  WYZ
  * @version V1.0
  * @date    2023-05-20
  * @brief   ����ӿڿ�����صĺ���
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "CTRL.h"
#include "DUT_reg.h"

extern DUT_DATA_LEN DATA_BYTE;
//==================================================================================================
//| function name     | Reset_Device()
//|----------|--------------------------------------------------------------------------------------
//| brief             | 
//|----------|--------------------------------------------------------------------------------------
//| parameter         | 
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2022/11/16
uint32_t Reset_Device(void) 
{
		DUT_START_H;
		delay_ms(1);
	
		DUT_RESET_L;
		delay_ms(1);
	
		DUT_RESET_H;
		delay_ms(2);

		return 0;
}
//| function name     | SPI_WriteReg()
//|----------|--------------------------------------------------------------------------------------
//| brief             | SPI���Ĵ���
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/22


void SPI_WriteReg(uint8_t FirstAddr,uint8_t Length,uint16_t *DATA)
{
		unsigned int Index;
		uint16_t ReadBuffser;
		
		DUT_CS_L;																												//-----------------
		if(!Length) {Length =1;}
		
		SPI2->DR = Wreg|FirstAddr; 																			//--------Send Command 
		while((SPI2->SR & SPI_I2S_FLAG_TXE)  == (uint16_t)RESET);				//-----�ȴ��������
		while((SPI2->SR & SPI_I2S_FLAG_RXNE) == (uint16_t)RESET);				//-----�ȴ��������---GD103����Ҫ�Ƚ�����ɣ����������쳣
		ReadBuffser = SPI2->DR;
		
		SPI2->DR = Length - 1; 																					//------------Send length
		while((SPI2->SR & SPI_I2S_FLAG_TXE)  == (uint16_t)RESET);				//-----�ȴ��������
		while((SPI2->SR & SPI_I2S_FLAG_RXNE) == (uint16_t)RESET);				//-----�ȴ��������---GD103����Ҫ�Ƚ�����ɣ����������쳣
		ReadBuffser = SPI2->DR;
		
		for(Index=FirstAddr;Index<(FirstAddr+Length);Index++)
		{		
				SPI2->DR = DATA[Index];
				while((SPI2->SR & SPI_I2S_FLAG_TXE)  == (uint16_t)RESET);		//-----�ȴ��������
				while((SPI2->SR & SPI_I2S_FLAG_RXNE) == (uint16_t)RESET);		//-----�ȴ��������---GD103����Ҫ�Ƚ�����ɣ����������쳣
				ReadBuffser = SPI2->DR;
		}
		while((SPI2->SR & SPI_I2S_FLAG_BSY)  == (uint16_t)SET);		
		delay_us(2);																										//     Tsccs > 7* Tclk
		DUT_CS_H;
}
//| function name     | SPI_Write()
//|----------|--------------------------------------------------------------------------------------
//| brief             | SPI
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/22


uint16_t SPI_Write(uint16_t data)
{
		uint16_t ReadBuffser;
		
		SPI2->DR = data; //--------Send Command 
		while((SPI2->SR & SPI_I2S_FLAG_TXE)  == (uint16_t)RESET);//-----�ȴ��������
		while((SPI2->SR & SPI_I2S_FLAG_RXNE) == (uint16_t)RESET);//-----�ȴ��������---GD103����Ҫ�Ƚ�����ɣ����������쳣
		ReadBuffser = SPI2->DR;		

		return   ReadBuffser;
}
//| function name    | SPI_Read()
//|----------|--------------------------------------------------------------------------------------
//| brief             | SPIд�Ĵ���
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/22
void SPI_ReadReg(uint8_t FirstAddr,uint8_t Length,uint16_t *DATA)
{
	unsigned int Index;
	uint16_t ReadBuffser;
	
	DUT_CS_L;//-----------------
	if(!Length) {Length =1;}
	
	SPI2->DR = Rreg|FirstAddr; //--------Send Command 
	while((SPI2->SR & SPI_I2S_FLAG_TXE)  == (uint16_t)RESET);//-----�ȴ��������
	while((SPI2->SR & SPI_I2S_FLAG_RXNE) == (uint16_t)RESET);//-----�ȴ��������---GD103����Ҫ�Ƚ�����ɣ����������쳣
	ReadBuffser = SPI2->DR;
	
	SPI2->DR = Length - 1; //------------Send length
	while((SPI2->SR & SPI_I2S_FLAG_TXE)  == (uint16_t)RESET);//-----�ȴ��������
	while((SPI2->SR & SPI_I2S_FLAG_RXNE) == (uint16_t)RESET);//-----�ȴ��������---GD103����Ҫ�Ƚ�����ɣ����������쳣
	ReadBuffser = SPI2->DR;
	
	for(Index=FirstAddr;Index<(FirstAddr+Length);Index++)
	{		
			SPI2->DR = NOP;
			while((SPI2->SR & SPI_I2S_FLAG_TXE)  == (uint16_t)RESET);//-----�ȴ��������
			while((SPI2->SR & SPI_I2S_FLAG_RXNE) == (uint16_t)RESET);//-----�ȴ��������---GD103����Ҫ�Ƚ�����ɣ����������쳣
			DATA[Index] = SPI2->DR;//--when reading ,Send NOP Command.
	}
	while((SPI2->SR & SPI_I2S_FLAG_BSY)  == (uint16_t)SET);		
	DUT_CS_H;//-----------------
}
//| function name     | NVIC_Configuration()
//|----------|--------------------------------------------------------------------------------------
//| brief             | NVIC��ʼ��
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/20
void waiting_DRDY(void)
{
	while((GPIOB->IDR & GPIO_Pin_11) == Bit_RESET){}
	while((GPIOB->IDR & GPIO_Pin_11) != Bit_RESET){}							// waiting DRDY Down edge
}
//| function name     | NVIC_Configuration()
//|----------|--------------------------------------------------------------------------------------
//| brief             | NVIC��ʼ��
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/20
void SPI_RESET_ALL(void)
{
  DUT_CS_L;
	SPI2->DR = 0xff;	while( (SPI2->SR & SPI_I2S_FLAG_TXE ) == RESET ){}
	SPI2->DR = 0xff;	while( (SPI2->SR & SPI_I2S_FLAG_TXE ) == RESET ){}
	SPI2->DR = 0xff;	while( (SPI2->SR & SPI_I2S_FLAG_TXE ) == RESET ){}
	SPI2->DR = 0xff;	while( (SPI2->SR & SPI_I2S_FLAG_TXE ) == RESET ){}
	char tp=SPI2->DR;	while( (SPI2->SR & SPI_I2S_FLAG_RXNE) == RESET ){}
  DUT_CS_H;
}
