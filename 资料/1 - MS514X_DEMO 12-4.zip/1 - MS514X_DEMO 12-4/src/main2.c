/**
 ******************************************************************************
 * @file    main.c
 * @author  WYZ
 * @version V1.0
 * @date    2023-05-22
 * @brief   �����������·ͨ��ʹ�õ���SPI2
 ******************************************************************************
 * @attention
 *
 * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
 * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
 * TIME. AS A RESULT, RELMON SHALL NOT BE HELD LIABLE FOR ANY
 * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
 * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
 * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
 *
 ******************************************************************************
 **/

/* Includes ------------------------------------------------------------------*/
#include <stm32f10x.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
// #include <system.h>

#include "main.h"
#include "Delay.h"
#include "initial.h"
#include "CTRL.h"
#include "DUT_reg.h"
#include "functional.h"

int uart1_rxbuf_num;
char uart1_rxbuf[uart1_rxbuf_num_max] = {0};
bool UART1_Receive_flag = false;
bool DRDY_flag = false;

DUT_DATA_LEN DATA_BYTE;
int Value;

uint16_t RegList[15];
uint16_t SetList[15];

Work_Mode_TYPE work_mode;
double AVG_value;

COMMAND_TYPE U_COMMAND = COMMAND_NORMAL;
Register_TYPE program_register;
int Continuity_Convert_Times;
bool Continuity_Convert_flag = false;
int CCcalnum;

#define _PRINTF_
int fputc(int ch, FILE *f)
{
	USART_SendData(USART1, (unsigned char)ch);
	while (!(USART1->SR & USART_FLAG_TXE))
		;
	return (ch);
}

double RTD_Value1, RTD_Value2;
int value[16] = {0};
int main(void)
{
	Initialization();

	printf("\033[2J\n\t\t***** MS5148 DEMO  *****\r\n");
	printf("\033[7;1H");
	printf("\t1. оƬ�ڲ��¶ȴ�����\r\n\r\n");
	printf("\t2. ����RTD��PT100\r\n\r\n");
	printf("\033[17;17H���� 1 - 2 ѡ����Ŀ\r\n");
	printf("\033[19;14H*** �������˿Ƽ��ɷ����޹�˾  ***");

	Reset_Device();
	SPI_ReadReg(MUX0, 15, RegList);
	//	SPI_Read(IDreg,&Value);
	printf("\033[4;15HMS5148 Reseted & ID is 0x%X\033[17;8H", (uint8_t)(RegList[10] >> 4));

	bool RTD_Iout1, RTD_Iout2;
	while (1)
	{
		if (value[0] < 0x100000)
		{
			value[0] += 1;
		}
		
		if (Continuity_Convert_Times == -1)
		{
			if (work_mode == Mode_inside_temp) // �ڲ��¶ȴ�����
			{
				double inside_tempture_data = (Vref * (AVG_value) / 16777216 * 2 - 0.1036) / 0.0003749;
				printf("\033[7;32H%7.1f ��", inside_tempture_data);
				Continuity_Convert_Times = TIMES_inside_temp;
				EXTI->PR = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;
			}
			if (work_mode == Mode_RTD) // �������RTD
			{
				if (RTD_Iout1)
				{
					// RTD_Value1 = (AVG_value / 8388607) * 3000;
					RTD_Value1 = (AVG_value / 8388607) * 2200 * 2;
					//					RTD_Value1 = ((Vref*(AVG_value/16777216)*2)/16)/0.0001;
//					printf("\033[14;1H\033[K\033[14;32H%7.4f ��", RTD_Value1);
					printf("%7.4f ��\n",RTD_Value1);
					// Continuity_Convert_Times = TIMES_RTD;
					Continuity_Convert_Times = 0;
					EXTI->PR = _EXTI_DUT_DRDY;
					EXTI->IMR |= _EXTI_DUT_DRDY;
				}
			}
		}

		if (UART1_Receive_flag)
		{
			UART1_Receive_flag = false;
			if ((uart1_rxbuf[0] == '1') || (uart1_rxbuf[0] == '2') || (uart1_rxbuf[0] == '3') || (uart1_rxbuf[0] == '4') || (uart1_rxbuf[0] == '5') || (uart1_rxbuf[0] == '0'))
			{
				printf("\033[7;6H  \033[1B\033[K\033[9;6H  \033[1B\033[K\033[11;6H  \033[1B\033[K\033[13;6H  \033[1B\033[K\033[15;6H  \033[1B\033[K\033[1B\033[K");
				waiting_DRDY();
				_Stop_Convert_Command();
			}
			//
			if (!strncmp(uart1_rxbuf, "1", 1)) // �ڲ��¶ȴ�����
			{
				printf("\033[7;6H��");

				SetList[SYS0] = 0;
				SPI_WriteReg(SYS0, 1, SetList);

				SetList[MUX1] = (VREFCON0) | (REFSEL1) | (MUXCAL0 | MUXCAL1);
				SPI_WriteReg(MUX1, 1, SetList);

				SPI_ReadReg(MUX0, 15, RegList);

				_Continuity_Converts_Command();
				Continuity_Convert_Times = 1 + TIMES_inside_temp;
				// FIXME: �����CCcalnum�����ÿ���������
				// CCcalnum ��ֱ�ӽ�������RTDʱ������
				CCcalnum = TIMES_inside_temp;
				EXTI->PR = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;
				work_mode = Mode_inside_temp;
			}
			// FIXME: ����ʹ����������RTD��ʵ�ʵ���Դ��ʹ��1�����޷��ﵽ����RTD��·�迹��Ч��
			if (!strncmp(uart1_rxbuf, "2", 1)) // �������RTD
			{
				printf("\033[9;6H��");
				// MUX0 addr��0
				// �رյ���Դ + AinP2 + AinN3
				SetList[MUX0] = (MUX_SP1) | (MUX_SN1 | MUX_SN0);
				SPI_WriteReg(MUX0, 1, SetList);
				// VBIAS addr��1
				// Ĭ�� VBIASȫ������
				// MUX1 addr��2
				// �ڲ�ʱ�� + �ڲ���׼���� + �ⲿ��׼ref1 + ����У׼
				// SYS0 addr��3
				// PGA1 + SPS20

				// SetList[SYS0] = (DR3 | DR1); //----
				SetList[SYS0] = (0x06); //----
									 //				SetList[SYS0] = (PGA2)|(DR1);     //----PGA=16
				SPI_WriteReg(SYS0, 1, SetList);

				SetList[MUX1] = (VREFCON0) | (REFSEL0) | (MUXCAL1);
				//				SetList[MUX1] = (VREFCON0)|(REFSEL1)|(MUXCAL1);
				SPI_WriteReg(MUX1, 1, SetList);

				printf("\033[14;28Hͨ������׼����У׼");

				DUT_CS_L;
				SPI_Write(Sysgcal);
				DUT_CS_H;
				waiting_DRDY();
				printf("��ɡ�");
				// MUX1 addr��2
				// �ڲ�ʱ�� + �ڲ���׼���� + �ⲿ��׼ref1 + ����ģʽ
				SetList[MUX1] = (VREFCON0) | (REFSEL0) & (~(MUXCAL0 | MUXCAL1 | MUXCAL2));
				//				SetList[MUX1] = (VREFCON0)|(REFSEL1)&(~(MUXCAL0|MUXCAL1|MUXCAL2));
				SPI_WriteReg(MUX1, 1, SetList);

				SPI_ReadReg(MUX0, 15, RegList);
				// IDAC0 addr��0x0A
				// ID + DRDY���� + ��������100uA
				SetList[IDAC0] = (IMAG1);
				SPI_WriteReg(IDAC0, 1, SetList);
				// IDAC1 addr��0x0B
				// ��������IEXC1 + ��������������
				// FIXME: �����IEXC1��IEXC2�����ÿ���������
				// SetList[IDAC1] = 0x8F;
				SetList[IDAC1] = 0x89;
				SPI_WriteReg(IDAC1, 1, SetList);

				SPI_ReadReg(MUX0, 15, RegList);

				RTD_Iout1 = true;
				RTD_Iout2 = false;
				_Continuity_Converts_Command();
				//Continuity_Convert_Times = 1 + TIMES_RTD;
				Continuity_Convert_Times = 1; // + TIMES_RTD;

				EXTI->PR = _EXTI_DUT_DRDY;
				EXTI->IMR |= _EXTI_DUT_DRDY;

				work_mode = Mode_RTD;
			}
		}
		if (DRDY_flag == true)
		{
			DRDY_flag = false;
			if (Continuity_Convert_Times--)
			{
				_Continuity_Converts_Read(&value[Continuity_Convert_Times + 1]);
				EXTI->IMR |= _EXTI_DUT_DRDY; // Enable EXTI line 14						GD32F103 BUG��
				EXTI->PR = _EXTI_DUT_DRDY;	 // Clear EXTI line 14 flag bit		The flag must be cleared immediately after the interrupt is enable
			}
			else
			{
				//_Continuity_Converts_Read(&value[Continuity_Convert_Times + 1]);
				_Continuity_Converts_Read(&value[0]);
				DUT_CS_H;
				// int SUM_value = 0;
				// for (int i = 0; i < CCcalnum; i++)
				// {
				// 	SUM_value += value[i];
				// }
				// AVG_value = (double)SUM_value / CCcalnum;
				AVG_value = value[0];
				EXTI->PR = _EXTI_DUT_DRDY; // Clear _EXTI_DUT_DRDY flag bit
			}
		}
	}
}

void USART1_IRQHandler(void)
{
	uart1_rxbuf[uart1_rxbuf_num] = (uint8_t)USART_ReceiveData(USART1);
	uart1_rxbuf_num++;
	USART_ClearFlag(USART1, USART_FLAG_RXNE);

	if (uart1_rxbuf_num == uart1_rxbuf_num_max)
		uart1_rxbuf_num = 0;
	//  if( (uart1_rxbuf[uart1_rxbuf_num-1]==0x0D) )
	{
		UART1_Receive_flag = true;
		uart1_rxbuf_num = 0;
	}
}
//| function name     | Initialization()
//|----------|--------------------------------------------------------------------------------------
//| brief             | �ܳ�ʼ������
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/20
void EXTI15_10_IRQHandler(void)
{
	if (EXTI_GetITStatus(_EXTI_DUT_DRDY) != RESET)
	{
		EXTI->IMR &= ~(_EXTI_DUT_DRDY); // disable _EXTI_DUT_DRDY
		EXTI->PR = _EXTI_DUT_DRDY;		// Clear  _EXTI_DUT_DRDY flag
		DRDY_flag = true;
	}
}
