#ifndef _CTRL_H_
#define _CTRL_H_

#include "stm32f10x.h"
#include "DUT_reg.h"

#define DUT_CS_H	GPIOB->BSRR	= GPIO_Pin_12;
#define DUT_CS_L	GPIOB->BRR	= GPIO_Pin_12;

#define DUT_CK_H	(GPIOB->BSRR  = GPIO_Pin_13)
#define DUT_CK_L	(GPIOB->BRR	  = GPIO_Pin_13)

#define DUT_MOSI_H	(GPIOB->BSRR  = GPIO_Pin_15)
#define DUT_MOSI_L	(GPIOB->BRR	  = GPIO_Pin_15)
//----------------------------------------------------//
#define DUT_START_H	(GPIOB->BSRR  = GPIO_Pin_10)
#define DUT_START_L	(GPIOB->BRR	  = GPIO_Pin_10)

#define DUT_RESET_H	(GPIOB->BSRR  = GPIO_Pin_9)
#define DUT_RESET_L	(GPIOB->BRR	  = GPIO_Pin_9)

#define _EXTI_DUT_DRDY  EXTI_Line11


uint32_t Reset_Device(void);

uint16_t SPI_Write(uint16_t data);
void SPI_Read(Register_TYPE REG,int *DATA);

void SPI_WriteReg(uint8_t FirstAddr,uint8_t Length,uint16_t *DATA);
void SPI_ReadReg(uint8_t FirstAddr,uint8_t Length,uint16_t *DATA);

void waiting_DRDY(void);
void SPI_RESET_ALL(void);

#endif
