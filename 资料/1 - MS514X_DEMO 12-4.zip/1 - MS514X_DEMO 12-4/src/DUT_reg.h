#ifndef _DUT_REG_H_
#define _DUT_REG_H_

typedef enum {
	Wakeup      = 0X00,Sleep   = 0X02,Sync     = 0X04,Reset = 0X06,
	Rreg        = 0x20,Wreg	   = 0x40,
	Rdata       = 0X12,Rdatac  = 0X14,Sdatac   = 0X16,
	Sysocal     = 0X60,Sysgcal = 0X61,Selfocal = 0X62,
	NOP         = 0XFF,
	Restricted  = 0XF1,
}	_COMMAND_TYPE;

typedef enum	{ 
			MUX0    = 0x00,VBIAS   = 0x01,MUX1 = 0x02,
			SYS0    = 0x03,
		  OFC0    = 0x04,OFC1    = 0x05,OFC2 = 0x06,
			FSC0    = 0x07,FSC1    = 0x08,FSC2 = 0x09,
			IDAC0   = 0x0A,IDAC1   = 0x0B,
			GPIOCFG = 0x0C,GPIODIR = 0x0D,GPIODAT= 0x0E
}Register_TYPE;

//MUX0 reg
#define	BCS1     0X80
#define	BCS0     0X40

#define	MUX_SP2 	0X20
#define	MUX_SP1 	0X10
#define	MUX_SP0 	0X08

#define	MUX_SN2 	0X04
#define	MUX_SN1 	0X02
#define	MUX_SN0 	0X01

//MUX1  reg
#define CLKSTAT  0x80

#define VREFCON1 0X40
#define VREFCON0 0X20

#define REFSEL1 0X10
#define REFSEL0 0X08

#define MUXCAL2 0X04
#define MUXCAL1 0X02
#define MUXCAL0 0X01

//SYS0  reg
#define PGA2 0X40
#define PGA1 0X20
#define PGA0 0X10

#define DR3 0X08
#define DR2 0X04
#define DR1 0X02
#define DR0 0X01
#define DRz 0X00
#define DR10P64 0X62
#define DR20P32 0X52
#define DR40P16 0X43
#define DR80P32 0X54
#define DR160P32 0X55
#define DR1KP16 0X48


//IDAC0  reg
#define ID 0XF0

#define DRDY_MODE 0X08

#define IMAG2 0X04
#define IMAG1 0X02
#define IMAG0 0X01

//IDAC1  reg
#define I1DIR3 0X80
#define I1DIR2 0X40
#define I1DIR1 0X20
#define I1DIR0 0X10

#define I2DIR3 0X08
#define I2DIR2 0X04
#define I2DIR1 0X02
#define I2DIR0 0X01

#endif
