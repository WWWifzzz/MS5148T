/**
  ******************************************************************************
  * @file    initial.c
  * @author  WYZ
  * @version V1.0
  * @date    2023-05-20
  * @brief   ���������ʼ������
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "initial.h"
#include "Delay.h"

//| function name     | RCC_Configuration()
//|----------|--------------------------------------------------------------------------------------
//| brief             | RCC (Reset and Clock Control) ��ʼ��
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/20
void RCC_Configuration(void)
{
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);	/* Enable GPIO clock */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 , ENABLE);	/* Enable USART1 clock */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2 , ENABLE);		/* Enable SPI2   clock */
}
//| function name     | NVIC_Configuration()
//|----------|--------------------------------------------------------------------------------------
//| brief             | NVIC��ʼ��, DRDY������PB11. �жϺ�����main.c��
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/22
void NVIC_Configuration(void)
{
	EXTI_InitTypeDef   EXTI_InitStructure;

  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource11);// DUT_DRDY int Connect EXTI14 Line to PB.11 pin */
	
  EXTI_InitStructure.EXTI_Line = EXTI_Line11;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;  			// falling edge
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
	EXTI->IMR &= ~(EXTI_Line11);																	// disable EXTI line 11
	EXTI->PR = EXTI_Line11;																				// Clear EXTI line 11 flag11

  NVIC_InitTypeDef NVIC_InitStructure;
  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
  
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;							// for PC or other CtrlMCU
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;					// DUT_DRDY
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
}
//| function name     | USART1_Configuration()
//|----------|--------------------------------------------------------------------------------------
//| brief             | USART1��ʼ��
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/20
void USART1_Configuration(void)
{
	USART_InitTypeDef USART_InitStructure;	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate = 1500000;													//115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART1, &USART_InitStructure); 

	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
	USART_Cmd(USART1, ENABLE);
}
//| function name     | SPI2_Configuration()
//|----------|--------------------------------------------------------------------------------------
//| brief             | SPI2��ʼ�� - ����������ڣ�������MS5148ͨ�ŵĽӿ�
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/20
void SPI2_Configuration(void)	
{
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_12; 						//--CS
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_14; 						//--MISO
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU; 					//--DOUT_DRDY need pull up
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_13|GPIO_Pin_15; //--SCLK / MOSI 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_SetBits(GPIOB,GPIO_Pin_12) ;
	
	SPI_InitTypeDef  SPI_InitStructure;
	
	SPI_Cmd(SPI2, DISABLE);
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_Mode 			= SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize 	= SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL 			= SPI_CPOL_Low;
	SPI_InitStructure.SPI_CPHA 			= SPI_CPHA_2Edge;
	SPI_InitStructure.SPI_NSS 			= SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;//----ʱ��̫���ͨ���쳣
	SPI_InitStructure.SPI_FirstBit 					= SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial 		= 7;
	SPI_Init(SPI2, &SPI_InitStructure);
	SPI_Cmd(SPI2, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_9; 				//--RESET
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_10; 				//--START
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP; 	
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_11; 				//--DRDY
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;      //--DRDY need pull up
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
}
//| function name     | Initialization()
//|----------|--------------------------------------------------------------------------------------
//| brief             | �ܳ�ʼ������
//|----------|--------------------------------------------------------------------------------------
//| parameter         | None
//|----------|--------------------------------------------------------------------------------------
//| retval            | None
//|----------|--------------------------------------------------------------------------------------
//| author and date   | wyz,2023/05/20


void Initialization()
{
	delay_init(72);
	RCC_Configuration();
	USART1_Configuration();
	SPI2_Configuration();
	NVIC_Configuration();
}
